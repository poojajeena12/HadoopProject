use edureka_572865;
select landmass, count(*) from country group by landmass;
