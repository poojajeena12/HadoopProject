use edureka_572865;
select zone, COUNT(*) from country group by zone;
