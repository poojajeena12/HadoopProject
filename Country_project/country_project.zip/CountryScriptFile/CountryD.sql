use edureka_572865;
select COUNT(*) from country where topleft=botright;
