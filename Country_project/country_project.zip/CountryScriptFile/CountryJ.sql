use edureka_572865;
select SUM(circles) from country;
