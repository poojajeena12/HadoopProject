use edureka_572865;
select mainhue, COUNT(*) as count_color from country group by mainhue order by count_color DESC limit 1;
