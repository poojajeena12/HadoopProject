use edureka_572865;
select name,area from country where zone=1 order by area DESC limit 1;
