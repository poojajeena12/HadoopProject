use edureka_572865;
select COUNT(name) from country where icon=1 AND text=1;
