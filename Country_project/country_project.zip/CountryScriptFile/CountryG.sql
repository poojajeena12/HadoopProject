use edureka_572865;
select name, population from country where landmass=2 order by population ASC limit 1;
