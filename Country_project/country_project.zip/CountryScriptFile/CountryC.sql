use edureka_572865;
select COUNT(*) from country where icon = 1;
