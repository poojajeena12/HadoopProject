use edureka_572865;
select name, SUM(bars + stripes) as bar_stripe from country group by name order by bar_stripe DESC limit 5;
